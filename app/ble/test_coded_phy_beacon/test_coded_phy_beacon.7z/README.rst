.. _bluetooth-beacon-coded-Phy sample.:

Bluetooth: Beacon with coded phy
#################

Overview
********

adv data includes full name, and manufacture specific data "Hello world". 



Requirements
************
any nordic nRF5 board. 

Building and Running
********************
...
